## Install Dependencies

npm init
npm i -D jest
npm install 
npm install --save-dev chai



## Run

npm run test
